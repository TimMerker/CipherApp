import com.codebind.CipherAppFrame;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class Main {




    public static void main(String[] args) {
        CipherAppFrame cipherAppFrame = new CipherAppFrame();
        String u = "I should have known that you would have a perfect answer for me!!!";
        String v = "J vltasl rlhr zdfog odxr ypw atasl rlhr p gwkzzyq zntyhv lvz wp!!!";
        CipherAppFrame.Compute compute = new CipherAppFrame.Compute();
        System.out.println(compute.movingShift(u,1));
        System.out.println(compute.demovingShift(v,1));
    }
}
